#include <stdio.h>
#include<unistd.h>
#include<stdlib.h>
void intro();
int main()
{
    system("clear");
    int c, in=0, i, re = 0;
    char p1[10] = {'X','X','X','X','X','X','X','X','X','X'};
    char p2[10] = {'O','O','O','O','O','O','O','O','O','O'}, m[10];
    for( c = 1; c <= 10; c++)
    {
        intro();
        if( c%2 == 0)
        {
            if( m[in] != 'O')
            {
                m[in] = p1[in];
            }
        }
        else
        {
            if( m[in] != 'X')
            {
                m[in] = p2[in];
            }
        }
        int n = 13, i, j, a, b, c, d, e, f, g, h, k;
        for( i = 0; i < n; i++)
        {
            for( j = 0; j < n; j++)
            {
                if( i%4 == 0 || j%4 == 0)
                {
                    printf(" *");
                }
                else if( i == 2 && j == 2)
                {
                   printf(" %c",m[1]);
                   a = m[1];
                }
                else if( i == 2 && j == 6)
                {
                   printf(" %c",m[2]);
                   b = m[2];
                }
                else if( i == 2 && j == 10)
                {
                   printf(" %c",m[3]);
                   c = m[3];
                }
                else if( i == 6 && j == 2)
                {
                    printf(" %c",m[4]);
                    d = m[4];
                }
                else if( i == 6 && j == 6)
                {
                    printf(" %c",m[5]);
                    e = m[5];
                }
                else if( i == 6 && j == 10)
                {
                    printf(" %c",m[6]);
                    f = m[6];
                }
                else if( i == 10 && j == 2)
                {
                    printf(" %c",m[7]);
                    g = m[7];
                }
                else if( i == 10 && j == 6)
                {
                    printf(" %c",m[8]);
                    h = m[8];
                }
                else if( i == 10 && j == 10)
                {
                    printf(" %c",m[9]);
                    k = m[9];
                }
                else
                {
                    printf("  ");
                }   
            }
            printf("\n");
        }
        if( a == 'X' && b == 'X' && c == 'X' || d == 'X' && e == 'X' && f == 'X' || g == 'X' && h == 'X' && k == 'X')
        {
            re++;
            break;
        }
        else if( a == 'X' && d == 'X' && g == 'X' || b == 'X' && e == 'X' && h == 'X' || c == 'X' && f == 'X' && k == 'X')
        {
            re++;
            break;
        }
        else if( a == 'X' && e == 'X' && k == 'X' || c == 'X' && e == 'X' && g == 'X')
        {
            re++;
            break;
        }
        else if( a == 'O' && b == 'O' && c == 'O' || d == 'O' && e == 'O' && f == 'O' || g == 'O' && h == 'O' && k == 'O')
        {
            break;
        }
        else if( a == 'O' && d == 'O' && g == 'O' || b == 'O' && e == 'O' && h == 'O' || c == 'O' && f == 'O' && k == 'O')
        {
            break;
        }
        else if( a == 'O' && e =='O' && k == 'O' || c == 'O' && e == 'O' && g == 'O')
        {
            break;
        }
        scanf("%d",&in);
        system("clear");
    }
    system("clear");
    if( re == 0)
    {
        printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t\t\t\t\t\tPLAYER 2🏆");
    }
    else
    {
        printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t\t\t\t\t\tPLAYER 1🏆");
    }
    printf("\n\n"
               "\t\t\t\t\t\t\t\t\t\t\t█░█░█ █ █▄░█\n"
               "\t\t\t\t\t\t\t\t\t\t\t▀▄▀▄▀ █ █░▀█\n");
    system("aplay win.wav > /dev/null 2>&1");
    char rr;
    scanf(" %c",&rr);
    if(rr=='a')
    {
	    system("clear");
	    system("./a.out");
    }
    return 0;
}
void intro()
{
            printf("\n\n\n\n\n\n"
"\e[1;35m ██╗  ██╗\e[1;37m █████╗ \e[1;35m██╗  ██╗\e[0m\n"
"\e[1;35m ╚██╗██╔╝\e[1;37m██╔V═██╗\e[1;35m╚██╗██╔╝\e[0m\n"
"\e[1;35m  ╚███╔╝ \e[1;37m██║C ██║\e[1;35m ╚███╔╝ \e[0m\n"
"\e[1;35m  ██╔██╗ \e[1;37m██║S ██║\e[1;35m ██╔██╗ \e[0m\n"
"\e[1;35m ██╔╝╚██╗\e[1;37m╚█████╔╝\e[1;35m██╔╝╚██╗\e[0m\n"
"\e[1;35m ╚═╝  ╚═╝\e[1;37m ╚════╝ \e[1;35m╚═╝  ╚═╝\e[0m\n");
}
